# ===============================================================================
# Map-specific lighting definitions
# ===============================================================================

# ===============================================================================
# MAP 43: Eclipseburg - Lila Haus
# ===============================================================================

# ==== LILA HAUS - NUR DIESE LICHTER SIND AKTIV ====
# LILA HAUS (unten rechts auf der Map)
# Basis: X 8-12, Y 17-19 (Dach beginnt bei Y=17)
# ===============================================================================

# Obere Fensterreihe (Dachbereich Y=17)
GameData::LightEffect.add({
  :id => :house_purple_window_top_left,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 8,
  :map_y => 17,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_top_center_left,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 9,
  :map_y => 17,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_top_center_right,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 10,
  :map_y => 17,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_top_right,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 11,
  :map_y => 17,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

# Mittlere Fensterreihe (Y=18)
GameData::LightEffect.add({
  :id => :house_purple_window_mid_left,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 8,
  :map_y => 18,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_mid_center_left,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 9,
  :map_y => 18,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_mid_center_right,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 10,
  :map_y => 18,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_mid_right,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 11,
  :map_y => 18,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

# Untere Fensterreihe (Y=19 - Basis)
GameData::LightEffect.add({
  :id => :house_purple_window_bottom_left,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 8,
  :map_y => 19,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_bottom_center_left,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 9,
  :map_y => 19,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_bottom_center_right,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 10,
  :map_y => 19,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

GameData::LightEffect.add({
  :id => :house_purple_window_bottom_right,
  :type => :rect,
  :width => 1,
  :height => 1,
  :map_x => 11,
  :map_y => 19,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})

# TEST: Kreis neben dem Haus
GameData::LightEffect.add({
  :id => :test_circle,
  :type => :circle,
  :radius => 80,
  :map_x => 13,     # Rechts neben dem Haus
  :map_y => 18,
  :map_id => 43,
  :day => false,
  :stop_anim => false
})
